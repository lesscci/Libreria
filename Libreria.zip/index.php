<?php 
//mostrar errores
ini_set('display_errors', 'On') ;


require_once __DIR__.'/vendor/autoload.php';

use App\App;

new App();