<?php

namespace App\Models;

class Llibre{

  //si es nulo ponemos un interrogante
  // ej: private ? string $edicion;
  private string $isbn;
  private string $autor;
  private string $titulo;
  private string $edicion;

  // Setters
  public function setIsbn($isbn){
    $this->isbn=$isbn;
  }
 public function setAutor($autor){
    $this->autor=$autor;
  }
   public function setTitulo($titulo){
    $this->titulo=$titulo;
  }

  public function setEdicion($edicion){
    $this->edicion=$edicion;
  }

  //select

  public function getIsbn(){
    return $this->isbn;
  }

  public function getAutor(){
    return $this->autor;
  }

  public function getTitulo(){
    return $this->titulo;
  }

  public function getEdicion(){
    return $this->isbn;
  }
  public function getEdicion(){
    return $this->isbn;
  }
  

  
}